package com.example.spring.domain;

public class User {
	
}
