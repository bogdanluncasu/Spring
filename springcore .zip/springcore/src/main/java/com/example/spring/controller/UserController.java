package com.example.spring.controller;

import com.example.spring.domain.User;

public class UserController {
	public void createUser(User user){
		// call UserService here
	}
}
