package com.example.spring.runner;

public interface ConfigRunner {
	void run();
}
